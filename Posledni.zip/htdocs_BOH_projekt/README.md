pridal jsem css od Honzika a s tim presmerovavani na tamní prihlaseni a registrace<br/>
login, logout i registrace funguje ale nemaji design 👍<br/>
email: admin@admin.cz heslo: admin<br/>
_____________________________________________<br/>
                                             <br/>
9.6.<br/>
upraveno prihlaseni a registrace, pridano css<br/>
pridan zebricek (zebricek.phtml, ZebricekKontroler.php, stylZebr.css) - NENI SPOJEN S DATABAZI<br/>
pridany mapa.phtml, MapaKontroler.php - nevyuzito<br/>
_____________________________________________<br/>
                                             <br/>