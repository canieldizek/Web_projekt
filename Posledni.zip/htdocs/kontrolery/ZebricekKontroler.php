<?php
class ZebricekKontroler extends Kontroler {
    public function zpracuj($parametry) {
        $this->pohled = "zebricek";
    }
}